/**
 * gemini.js - Multimodal AI & Groq Integration for 3D Floor Plan Digital Twin
 */

const API_KEY_STORAGE_KEY = 'digital_twin_gemini_api_key';
const GEMINI_MODEL = 'gemini-2.0-flash';

/**
 * Tool definitions for Gemini Function Calling
 */
export const geminiTools = [
    {
        functionDeclarations: [
            {
                name: 'setLayerVisibility',
                description: 'Toggle visibility of 3D building layers such as water pipes, electrical lines, emergency pathways, window shell, or multi-floor mode.',
                parameters: {
                    type: 'OBJECT',
                    properties: {
                        pipes: { type: 'BOOLEAN', description: 'Show or hide water pipes layer' },
                        electrical: { type: 'BOOLEAN', description: 'Show or hide electrical wiring layer' },
                        escape: { type: 'BOOLEAN', description: 'Show or hide emergency escape routes layer' },
                        windows: { type: 'BOOLEAN', description: 'Show or hide window shell layer' },
                        multiFloor: { type: 'BOOLEAN', description: 'Enable or disable multi-floor view mode' }
                    }
                }
            },
            {
                name: 'highlightFireZone',
                description: 'Highlight a specific room, floor, and block with a fire/emergency hazard alert overlay and effect.',
                parameters: {
                    type: 'OBJECT',
                    properties: {
                        blockIdx: { type: 'INTEGER', description: 'Block index (0 to 3)' },
                        roomIdx: { type: 'INTEGER', description: 'Room index (0 to 5)' },
                        floorIdx: { type: 'INTEGER', description: 'Floor index (0 to 5)' }
                    },
                    required: ['blockIdx', 'roomIdx', 'floorIdx']
                }
            },
            {
                name: 'toggleWalkthrough',
                description: 'Enter or exit first-person walkthrough mode inside the 3D building.',
                parameters: {
                    type: 'OBJECT',
                    properties: {
                        enable: { type: 'BOOLEAN', description: 'True to enter walkthrough mode, false to exit' }
                    },
                    required: ['enable']
                }
            },
            {
                name: 'setCameraPreset',
                description: 'Position the 3D camera to a predefined perspective or focus on a specific floor.',
                parameters: {
                    type: 'OBJECT',
                    properties: {
                        preset: {
                            type: 'STRING',
                            enum: ['isometric', 'top', 'front', 'side'],
                            description: 'Camera view angle preset'
                        },
                        floorIndex: { type: 'INTEGER', description: 'Optional floor index to focus camera target on' }
                    },
                    required: ['preset']
                }
            },
            {
                name: 'setFloorsCount',
                description: 'Set the number of building floors (override auto detection).',
                parameters: {
                    type: 'OBJECT',
                    properties: {
                        count: { type: 'INTEGER', description: 'Number of floors (1 to 20)' }
                    },
                    required: ['count']
                }
            },
            {
                name: 'clearBuildingScene',
                description: 'Clear the current 3D building model and reset the scene.',
                parameters: {
                    type: 'OBJECT',
                    properties: {}
                }
            }
        ]
    }
];

/**
 * Tool definitions for Groq / OpenAI Function Calling format
 */
export const groqTools = [
    {
        type: 'function',
        function: {
            name: 'setLayerVisibility',
            description: 'Toggle visibility of 3D building layers such as water pipes, electrical lines, emergency pathways, window shell, or multi-floor mode.',
            parameters: {
                type: 'object',
                properties: {
                    pipes: { type: 'boolean', description: 'Show or hide water pipes layer' },
                    electrical: { type: 'boolean', description: 'Show or hide electrical wiring layer' },
                    escape: { type: 'boolean', description: 'Show or hide emergency escape routes layer' },
                    windows: { type: 'boolean', description: 'Show or hide window shell layer' },
                    multiFloor: { type: 'boolean', description: 'Enable or disable multi-floor view mode' }
                }
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'highlightFireZone',
            description: 'Highlight a specific room, floor, and block with a fire/emergency hazard alert overlay and effect.',
            parameters: {
                type: 'object',
                properties: {
                    blockIdx: { type: 'integer', description: 'Block index (0 to 3)' },
                    roomIdx: { type: 'integer', description: 'Room index (0 to 5)' },
                    floorIdx: { type: 'integer', description: 'Floor index (0 to 5)' }
                },
                required: ['blockIdx', 'roomIdx', 'floorIdx']
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'toggleWalkthrough',
            description: 'Enter or exit first-person walkthrough mode inside the 3D building.',
            parameters: {
                type: 'object',
                properties: {
                    enable: { type: 'boolean', description: 'True to enter walkthrough mode, false to exit' }
                },
                required: ['enable']
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'setCameraPreset',
            description: 'Position the 3D camera to a predefined perspective or focus on a specific floor.',
            parameters: {
                type: 'object',
                properties: {
                    preset: {
                        type: 'string',
                        enum: ['isometric', 'top', 'front', 'side'],
                        description: 'Camera view angle preset'
                    },
                    floorIndex: { type: 'integer', description: 'Optional floor index to focus camera target on' }
                },
                required: ['preset']
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'setFloorsCount',
            description: 'Set the number of building floors (override auto detection).',
            parameters: {
                type: 'object',
                properties: {
                    count: { type: 'integer', description: 'Number of floors (1 to 20)' }
                },
                required: ['count']
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'clearBuildingScene',
            description: 'Clear the current 3D building model and reset the scene.',
            parameters: {
                type: 'object',
                properties: {}
            }
        }
    }
];

const DEFAULT_API_KEY = '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';

export function getApiKey() {
    const saved = localStorage.getItem(API_KEY_STORAGE_KEY);
    if (saved && (saved.startsWith('gsk_') || saved.startsWith('AIza'))) {
        return saved;
    }
    return DEFAULT_API_KEY;
}

export function setApiKey(key) {
    const trimmed = (key || '').trim();
    if (trimmed) {
        localStorage.setItem(API_KEY_STORAGE_KEY, trimmed);
    } else {
        localStorage.removeItem(API_KEY_STORAGE_KEY);
    }
    return trimmed;
}

const SYSTEM_INSTRUCTION = `
You are the AI Assistant for the 3D Floor Plan Digital Twin application.
Your role is to assist users in analyzing floor plans, managing building systems (water pipes, electrical wiring, emergency pathways, windows), inspecting hazard zones, and navigating the 3D scene.

Capabilities:
1. You can answer questions about floor plan analysis, building safety, facility management, and room measurements.
2. You can execute 3D scene actions via Function Calling tools:
   - setLayerVisibility: toggle visibility of pipes, electrical, escape routes, windows, or multi-floor.
   - highlightFireZone: highlight a fire/hazard in a specific room (blockIdx, roomIdx, floorIdx).
   - toggleWalkthrough: enter/exit 3D first-person walkthrough.
   - setCameraPreset: change camera view angle (isometric, top, front, side).
   - setFloorsCount: override number of floors (1-20).
   - clearBuildingScene: clear the 3D building.

When a user asks to perform an action on the 3D model (e.g., "show me water pipes", "highlight room 1 floor 0", "start walkthrough"), call the appropriate function tool. Always be concise, helpful, and professional.
`;

/**
 * Send prompt to AI API (automatically handles both Groq and Gemini)
 */
export async function queryGemini({ prompt, imageBase64, buildingContext, history = [], onActionExecute }) {
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("API Key is missing. Click the key icon in the AI Chat panel to set your API Key.");
    }

    // Auto-detect Groq API Key (starts with gsk_)
    if (apiKey.startsWith('gsk_')) {
        return await queryGroq({ prompt, buildingContext, history, onActionExecute, apiKey });
    }

    // Gemini API Request
    const contents = [];

    history.forEach(item => {
        contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.text }]
        });
    });

    const currentParts = [];
    if (imageBase64) {
        const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '');
        currentParts.push({
            inlineData: {
                mimeType: 'image/jpeg',
                data: cleanBase64
            }
        });
    }

    let fullPromptText = prompt;
    if (buildingContext) {
        fullPromptText += `\n\n[Current Building Context: ${JSON.stringify(buildingContext)}]`;
    }
    currentParts.push({ text: fullPromptText });

    contents.push({
        role: 'user',
        parts: currentParts
    });

    const requestBody = {
        systemInstruction: {
            parts: [{ text: SYSTEM_INSTRUCTION }]
        },
        contents: contents,
        tools: geminiTools
    };

    const modelsToTry = ['gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro'];
    let lastError = null;
    let response = null;

    for (const modelName of modelsToTry) {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${encodeURIComponent(apiKey)}`;
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });

            if (res.ok) {
                response = res;
                break;
            } else {
                const errorData = await res.json().catch(() => ({}));
                const msg = errorData.error?.message || `HTTP error ${res.status}: ${res.statusText}`;
                lastError = new Error(msg);
                if (res.status === 429 || msg.includes('quota') || msg.includes('Quota')) {
                    console.warn(`Model ${modelName} hit quota limit, trying fallback...`);
                    continue;
                } else {
                    throw lastError;
                }
            }
        } catch (e) {
            lastError = e;
        }
    }

    if (!response) {
        throw lastError || new Error("Failed to query Gemini models.");
    }

    const data = await response.json();
    const candidate = data.candidates?.[0];
    if (!candidate) {
        throw new Error("No response generated by Gemini.");
    }

    const modelParts = candidate.content?.parts || [];
    let textResponse = '';
    const actionsExecuted = [];

    for (const part of modelParts) {
        if (part.text) {
            textResponse += part.text + ' ';
        }
        if (part.functionCall) {
            const { name, args } = part.functionCall;
            if (typeof onActionExecute === 'function') {
                const resultText = onActionExecute(name, args);
                actionsExecuted.push({ name, args, resultText });
            }
        }
    }

    return {
        text: textResponse.trim() || (actionsExecuted.length > 0 ? `Executed action: ${actionsExecuted.map(a => a.name).join(', ')}` : 'Completed.'),
        actionsExecuted
    };
}

/**
 * Query Groq API (High Speed Llama 3.3 70B Engine)
 */
async function queryGroq({ prompt, buildingContext, history = [], onActionExecute, apiKey }) {
    const messages = [
        { role: 'system', content: SYSTEM_INSTRUCTION }
    ];

    history.forEach(item => {
        messages.push({
            role: item.role === 'user' ? 'user' : 'assistant',
            content: item.text
        });
    });

    let userPrompt = prompt;
    if (buildingContext) {
        userPrompt += `\n\n[Current Building Context: ${JSON.stringify(buildingContext)}]`;
    }
    messages.push({ role: 'user', content: userPrompt });

    const requestBody = {
        model: 'llama-3.3-70b-versatile',
        messages: messages,
        tools: groqTools,
        tool_choice: 'auto'
    };

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const msg = errorData.error?.message || `Groq API Error ${response.status}: ${response.statusText}`;
        throw new Error(msg);
    }

    const data = await response.json();
    const choice = data.choices?.[0]?.message;
    if (!choice) {
        throw new Error("No response returned from Groq API.");
    }

    let textResponse = choice.content || '';
    const actionsExecuted = [];

    if (choice.tool_calls && choice.tool_calls.length > 0) {
        for (const toolCall of choice.tool_calls) {
            const fnName = toolCall.function.name;
            let fnArgs = {};
            try {
                fnArgs = JSON.parse(toolCall.function.arguments || '{}');
            } catch (e) {}

            if (typeof onActionExecute === 'function') {
                const resultText = onActionExecute(fnName, fnArgs);
                actionsExecuted.push({ name: fnName, args: fnArgs, resultText });
            }
        }
    }

    return {
        text: textResponse.trim() || (actionsExecuted.length > 0 ? `Executed action: ${actionsExecuted.map(a => a.name).join(', ')}` : 'Completed.'),
        actionsExecuted
    };
}
